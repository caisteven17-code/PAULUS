"""
Shared data loading and feature engineering used by the model scripts.
"""

import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import joblib
import re
from collections.abc import Sequence

MONTH_ORDER = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]

MODELS_DIR = os.path.join(os.path.dirname(__file__), "models")
os.makedirs(MODELS_DIR, exist_ok=True)

DEFAULT_WORKBOOK_NAMES = (
    "2023.xlsx",
    "2024.xlsx",
    "2025.xlsx",
)


def load_data(source_path: str | Sequence[str] | None = None) -> pd.DataFrame:
    df = _load_source_data(source_path)

    if "month_num" not in df.columns:
        if "month" not in df.columns:
            raise KeyError(
                "Input data must contain either 'month' or 'month_num'. "
                "If you are using raw Excel workbooks, keep the annual .xlsx files "
                "in this folder."
            )
        df["month_num"] = df["month"].map({m: i + 1 for i, m in enumerate(MONTH_ORDER)})

    le = LabelEncoder()
    df["parish_id"] = le.fit_transform(df["parish_name"])
    joblib.dump(le, os.path.join(MODELS_DIR, "parish_label_encoder.joblib"))

    receipt_cols = [
        "collections_mass", "collections_other", "collections_other_receipts",
        "sacraments_arancel", "sacraments_parish_share", "sacraments_over_above",
    ]
    for col in receipt_cols:
        if col not in df.columns:
            df[col] = np.nan
    df["total_receipts_derived"] = df[receipt_cols].sum(axis=1, min_count=1)

    if "total_receipts" in df.columns:
        df["total_receipts_final"] = df["total_receipts"].combine_first(df["total_receipts_derived"])
    else:
        df["total_receipts_final"] = df["total_receipts_derived"]

    expense_cols = ["expenses_pastoral", "expenses_parish"]
    for col in expense_cols:
        if col not in df.columns:
            df[col] = np.nan
    df["total_expenses_derived"] = df[expense_cols].sum(axis=1, min_count=1)

    if "total_expenses" in df.columns:
        df["total_expenses_final"] = df["total_expenses"].combine_first(df["total_expenses_derived"])
    else:
        df["total_expenses_final"] = df["total_expenses_derived"]

    if "net_receipts_deficit" not in df.columns or df["net_receipts_deficit"].isna().all():
        df["net_receipts_deficit"] = df["total_receipts_final"] - df["total_expenses_final"]

    return df


def _load_source_data(source_path: str | Sequence[str] | None = None) -> pd.DataFrame:
    if source_path is None:
        workbook_paths = _find_fallback_workbooks(os.path.dirname(__file__))
        if workbook_paths:
            return _load_raw_workbooks(workbook_paths)
        raise FileNotFoundError("No annual Excel workbooks found. Expected 2023.xlsx, 2024.xlsx, and 2025.xlsx.")

    if isinstance(source_path, Sequence) and not isinstance(source_path, (str, bytes, os.PathLike)):
        return _load_raw_workbooks([str(path) for path in source_path])

    source_path = str(source_path)
    workbook_paths = _find_fallback_workbooks(source_path)

    if os.path.exists(source_path):
        if source_path.lower().endswith((".xlsx", ".xls")):
            return _load_raw_workbooks([source_path])

        df = pd.read_csv(source_path)
        if "month" in df.columns or "month_num" in df.columns:
            return df

    if workbook_paths:
        return _load_raw_workbooks(workbook_paths)

    if os.path.exists(source_path):
        raise KeyError(
            f"{os.path.basename(source_path)} does not have normalized model columns "
            "such as 'month' and 'parish_name'. Use the raw annual Excel workbooks "
            "2023.xlsx, 2024.xlsx, and 2025.xlsx."
        )

    raise FileNotFoundError(source_path)


def _find_fallback_workbooks(csv_path: str) -> list[str]:
    base_dir = csv_path if os.path.isdir(csv_path) else (os.path.dirname(csv_path) or ".")
    annual_paths = [
        os.path.join(base_dir, filename)
        for filename in DEFAULT_WORKBOOK_NAMES
        if os.path.exists(os.path.join(base_dir, filename))
    ]
    annual_paths.extend(_discover_annual_workbooks(base_dir))
    return _unique_paths(sorted(annual_paths))


def _discover_annual_workbooks(base_dir: str) -> list[str]:
    if not os.path.isdir(base_dir):
        return []

    paths = []
    for filename in os.listdir(base_dir):
        if re.fullmatch(r"20\d{2}\.xlsx?", filename, re.IGNORECASE):
            paths.append(os.path.join(base_dir, filename))
    return sorted(paths)


def _unique_paths(paths: Sequence[str]) -> list[str]:
    seen = set()
    unique = []
    for path in paths:
        normalized = os.path.abspath(path).lower()
        if normalized not in seen:
            seen.add(normalized)
            unique.append(path)
    return unique


def _load_raw_workbooks(workbook_paths: Sequence[str]) -> pd.DataFrame:
    frames = []
    for workbook_path in workbook_paths:
        workbook_df = _load_raw_workbook(workbook_path)
        workbook_df["source_workbook"] = os.path.basename(workbook_path)
        frames.append(workbook_df)

    if not frames:
        raise ValueError("No Excel workbooks were provided.")

    df = pd.concat(frames, ignore_index=True)
    return df.drop_duplicates().reset_index(drop=True)


def _load_raw_workbook(workbook_path: str) -> pd.DataFrame:
    book = pd.ExcelFile(workbook_path)
    frames = []

    for sheet_name in book.sheet_names:
        match = _parse_month_sheet_name(sheet_name, workbook_path)
        if not match:
            continue

        raw = pd.read_excel(book, sheet_name=sheet_name, header=None)
        frames.append(_parse_month_sheet(raw, match["month"], match["year"]))

    if not frames:
        raise ValueError(f"No monthly sheets found in {workbook_path}")

    return pd.concat(frames, ignore_index=True)


def _parse_month_sheet_name(sheet_name: str, workbook_path: str) -> dict[str, int | str] | None:
    cleaned = sheet_name.strip()
    match = re.fullmatch(r"([A-Za-z]+)(?:\s+(\d{4}))?", cleaned)
    if not match or match.group(1) not in MONTH_ORDER:
        return None

    workbook_year = re.search(r"(20\d{2})", os.path.basename(workbook_path))
    year_text = match.group(2) or (workbook_year.group(1) if workbook_year else None)
    if year_text is None:
        return None

    return {"month": match.group(1), "year": int(year_text)}


def _parse_month_sheet(raw: pd.DataFrame, month: str, year: int) -> pd.DataFrame:
    parish_col = _detect_parish_column(raw)
    parsed = pd.DataFrame({
        "parish_name": raw.iloc[:, parish_col],
        "sacraments_rate": _col(raw, parish_col + 1),
        "sacraments_arancel": _col(raw, parish_col + 2),
        "sacraments_parish_share": _col(raw, parish_col + 3),
        "sacraments_over_above": _col(raw, parish_col + 4),
        "collections_mass": _col(raw, parish_col + 5),
        "collections_other": _col(raw, parish_col + 6),
        "collections_other_receipts": _col(raw, parish_col + 7),
        "total_receipts": _col(raw, parish_col + 8),
        "expenses_pastoral": _col(raw, parish_col + 10),
        "expenses_parish": _col(raw, parish_col + 11),
        "total_expenses": _col(raw, parish_col + 12),
        "net_receipts_deficit": _col(raw, parish_col + 13),
        "mass_intentions_not_claimed": _col(raw, parish_col + 15),
        "mass_intentions_claimed": _col(raw, parish_col + 16),
        "special_collections": _col(raw, parish_col + 17),
        "pastoral_parish_fund_total_net_receipts": _col(raw, parish_col + 18),
    })

    parsed["parish_name"] = parsed["parish_name"].astype(str).str.strip()
    parsed = parsed[_is_parish_row(parsed["parish_name"])].copy()
    parsed["month"] = month
    parsed["year"] = year
    parsed["month_num"] = MONTH_ORDER.index(month) + 1

    for col in parsed.columns.difference(["parish_name", "month"]):
        parsed[col] = _to_number(parsed[col])

    return parsed.reset_index(drop=True)


def _detect_parish_column(raw: pd.DataFrame) -> int:
    best_col = 0
    best_count = -1
    for col in raw.columns:
        count = _is_parish_row(raw.iloc[:, col].astype(str).str.strip()).sum()
        if count > best_count:
            best_col = col
            best_count = count
    return best_col


def _is_parish_row(names: pd.Series) -> pd.Series:
    upper = names.str.upper()
    invalid = (
        names.isna()
        | names.eq("")
        | upper.eq("NAN")
        | upper.str.contains("DISTRICT", na=False)
        | upper.str.contains("SUMMARY", na=False)
        | upper.str.contains("SACRAMENTS", na=False)
        | upper.str.contains("COLLECTIONS", na=False)
        | upper.str.contains("EXPENSES", na=False)
        | upper.str.contains("TOTAL", na=False)
        | upper.str.contains("RATE", na=False)
        | upper.str.contains("NET OF", na=False)
    )
    return ~invalid & names.str.contains(",", regex=False, na=False)


def _col(raw: pd.DataFrame, index: int) -> pd.Series:
    if index >= len(raw.columns):
        return pd.Series(np.nan, index=raw.index)
    return raw.iloc[:, index]


def _to_number(series: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(series):
        return series

    cleaned = series.astype(str).str.strip()
    missing = cleaned.str.lower().isin({"nan", "none", ""})
    cleaned = (
        cleaned.mask(missing)
        .str.replace("%", "", regex=False)
        .str.replace(",", "", regex=False)
        .str.replace(r"^\((.*)\)$", r"-\1", regex=True)
    )
    numeric = pd.to_numeric(cleaned, errors="coerce")
    if series.astype(str).str.contains("%", regex=False).any():
        numeric = numeric / 100
    return numeric


def print_metric_table(df: pd.DataFrame, percent_cols: Sequence[str] | None = None,
                       decimal_cols: dict[str, int] | None = None,
                       columns: Sequence[str] | None = None) -> None:
    display = df if columns is None else df[list(columns)]
    formatters = {}

    for col in percent_cols or []:
        if col in display.columns:
            formatters[col] = lambda value: "" if pd.isna(value) else f"{value:.2f}%"

    for col, decimals in (decimal_cols or {}).items():
        if col in display.columns:
            formatters[col] = lambda value, places=decimals: "" if pd.isna(value) else f"{value:.{places}f}"

    print(display.to_string(index=False, formatters=formatters))


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.sort_values(["parish_id", "year", "month_num"]).reset_index(drop=True)

    df["month_sin"] = np.sin(2 * np.pi * df["month_num"] / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["month_num"] / 12)

    df["sacraments_rate"] = (
        df.groupby("parish_id")["sacraments_rate"]
        .transform(lambda x: x.fillna(x.median()))
        .fillna(df["sacraments_rate"].median())
    )

    for lag in [1, 2, 3]:
        df[f"collections_lag{lag}"] = (
            df.groupby("parish_id")["total_receipts_final"].shift(lag)
        )

    df["collections_roll3"] = (
        df.groupby("parish_id")["total_receipts_final"]
        .transform(lambda x: x.shift(1).rolling(3, min_periods=1).mean())
    )

    df["collections_mom_growth"] = (
        df.groupby("parish_id")["total_receipts_final"]
        .pct_change()
        .clip(-2, 2)
    )

    denom = df["total_receipts_final"].replace(0, np.nan)
    df["net_margin"] = df["net_receipts_deficit"] / denom

    df["parish_mean_collections"] = (
        df.groupby("parish_id")["total_receipts_final"].transform("mean")
    )
    df["parish_std_collections"] = (
        df.groupby("parish_id")["total_receipts_final"].transform("std").fillna(0)
    )

    df["collections_zscore"] = (
        (df["total_receipts_final"] - df["parish_mean_collections"])
        / df["parish_std_collections"].replace(0, np.nan)
    ).fillna(0)

    return df
